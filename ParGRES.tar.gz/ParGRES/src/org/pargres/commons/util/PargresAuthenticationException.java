/*
 * Created on 08/04/2005
 */
package org.pargres.commons.util;


/**
 * @author Bernardo
 */
public class PargresAuthenticationException extends PargresException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3258133557158688309L;

	public PargresAuthenticationException(String problemDesc) {
		super(problemDesc);
	}
}
