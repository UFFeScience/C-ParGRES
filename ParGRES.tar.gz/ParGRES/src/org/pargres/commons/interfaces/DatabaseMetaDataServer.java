package org.pargres.commons.interfaces;

import java.rmi.Remote;

public interface DatabaseMetaDataServer extends java.sql.DatabaseMetaData, Remote {

}
