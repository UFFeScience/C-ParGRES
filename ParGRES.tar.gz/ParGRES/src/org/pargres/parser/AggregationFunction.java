package org.pargres.parser;

public class AggregationFunction {
	private int functionId;	
	public AggregationFunction(int functionId){
		this.functionId = functionId;
		}
	public int getFunctionId() {
		return functionId;
	}	
}
