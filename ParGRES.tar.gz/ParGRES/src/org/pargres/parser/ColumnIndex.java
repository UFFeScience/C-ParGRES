package org.pargres.parser;

public class ColumnIndex {
	public int index;
	public ColumnIndex(int i){
		index = i;
	}
}
