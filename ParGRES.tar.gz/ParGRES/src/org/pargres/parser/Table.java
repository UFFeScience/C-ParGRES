package org.pargres.parser;

public class Table {
	public String table;
	public String alias;
	public Table(String table, String alias){
		this.table=table;
		this.alias = alias;		
	}
}
