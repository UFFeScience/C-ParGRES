package org.pargres.parser;

public class Operator {
	public int id;
	public Operator(int i){
		id=i;
	}
}
