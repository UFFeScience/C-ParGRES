Pargres User Manual
=======================================================================
1. Installation Structure

2. Cluster Configuration

3. Startup

4. Already Tested Databases

5. Known Bugs

6. Limitations