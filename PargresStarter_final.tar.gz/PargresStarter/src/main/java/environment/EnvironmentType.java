package environment;

/**
 *
 * @author vitor
 */
public enum EnvironmentType {
    CLOUD_AMAZON,
    CLUSTER,
}
