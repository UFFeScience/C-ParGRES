package enumeration;

/**
 *
 * @author vitor
 */
public enum NodeType {
    CONTROL,
    SUPERNODE,
    NODE,
    UNKNOWN
}
