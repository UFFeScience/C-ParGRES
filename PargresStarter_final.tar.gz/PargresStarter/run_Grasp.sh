cd ~/GraspCC-Heuristic/
./Release/GraspCC inst/instance_act1.conf 0.5 0.5 > saida/output_instance_act1.conf
